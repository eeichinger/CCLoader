This is the ZNP version of the coordinator firmware. It means you need an external application that controls
CC253x chip through this firmware.

For example: https://github.com/Koenkk/zigbee2mqtt

coord-cc2530-rfx2401c.hex
=====================
The firmware is compiled for a particular version of the CC2530 board with the additional RFX2401C RF chip.

coord-cc2530-cc2591.hex
=====================
The firmware is compiled for a particular version of the CC2530 board with the additional CC2591 RF chip.

Lights
=========================
Depends on the software application.

Pairing
=========================
Flash firmware and permit joining to a network in your software application.


-------------------
Home page: https://ptvo.info